# gvimPortable7.4
介绍：配置好了常用插件（Windows 与 Linux 通用）
更多：[http://www.oschina.net/code/snippet_574132_13357](http://www.oschina.net/code/snippet_574132_13357)

百度云下载：[http://pan.baidu.com/s/1mgJXl7U](http://pan.baidu.com/s/1mgJXl7U)

---

# 改动地方
+ 增加:
	supertab
	vim-nerdtree-tabs
	vim-python-pep8-indent

+ 增加python感知.
+ ky.vim内容拷贝到~/.vim/目录下.
+ 执行：mv ky.vimrc ~/.vimrc 命令.

---
